@echo off
title DesignCraft Launcher
echo ===================================================
echo             Launching DesignCraft...
echo ===================================================
echo 1. Starting PowerShell Backend Server (Port 5000)...
echo 2. Opening your web browser to http://localhost:5000/
echo.
echo Leave this window open while using the app.
echo Press Ctrl+C in this window to stop the server.
echo ===================================================
echo.

:: Open the browser in a separate thread
start "" "http://localhost:5000/"

:: Start the server script in the current window
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0backend\server.ps1"

pause
