# DesignCraft: Interactive Web Design Playground ✦

Welcome to **DesignCraft**, a full-stack educational playground built to teach modern web design and backend integration. 

This app has **zero installation requirements**! It runs a custom frontend in your browser and is powered by a lightweight backend server written in PowerShell that serves files and acts as a database.

---

## 🚀 How to Run the App (Windows)

1. Double-click the `run.bat` file in the root of this folder.
2. A command line window will open, and your web browser will automatically load `http://localhost:5000/`.
3. Keep the command line window open while you use the application. To stop the server, close the window or press `Ctrl + C`.

---

## 🎨 Web Design Lessons Built-In

This project is structured specifically to teach you key principles of frontend design. Let's break down what you'll learn by studying the codebase:

### 1. Color Theory and Harmonies (Look at `app.js` → `generatePalette()`)
Web design relies heavily on color relationships. Standard hex colors (`#0ea5e9`) can be hard to calculate mathematically. In our code, we convert hex inputs into the **HSL (Hue, Saturation, Lightness)** color space:
- **Hue (0–360)**: The color wheel angle.
- **Saturation (0–100%)**: The intensity of the color.
- **Lightness (0–100%)**: The brightness (0% is black, 100% is white).

Using HSL, we programmatically generate color schemes:
*   **Analogous**: Hues adjacent to each other (e.g., base Hue $\pm 30^\circ$). Creates calm, comfortable designs.
*   **Complementary**: Opposite hues ($180^\circ$ apart). Creates high contrast and calls attention.
*   **Triadic**: Three hues spaced equally ($120^\circ$ apart). Creates vibrant, balanced layouts.

### 2. WCAG Contrast and Accessibility (Look at `app.js` → `getContrastRatio()`)
Good web design is accessible to everyone. The **Web Content Accessibility Guidelines (WCAG)** require text to have sufficient contrast against its background:
*   **AA Level**: Requires a contrast ratio of at least **4.5:1** for normal text.
*   **AAA Level**: Requires a contrast ratio of at least **7:1** (highest standard).

Our JavaScript code dynamically calculates contrast by computing the **Relative Luminance** ($L$) of the background and text using the official W3C formula:
$$L = 0.2126 \times R + 0.7152 \times G + 0.0722 \times B$$
The contrast ratio is calculated as:
$$\text{Ratio} = \frac{L_1 + 0.05}{L_2 + 0.05}$$
*(Where $L_1$ is the lighter color and $L_2$ is the darker).*

### 3. Typography Hierarchy (Look at `styles.css` → `:root` & `index.html` → `select`)
We load Google Fonts dynamically to preview pairings:
*   **Headlines (`Outfit` or `Playfair Display`)**: Large, bold fonts that establish structure. Serif fonts (like Playfair) look classic and literary, while Sans-serif (like Outfit) looks sleek and modern.
*   **Body (`Inter`)**: Highly legible, clean Sans-serif font meant for comfortable reading.
*   **Monospace (`Fira Code`)**: Fixed-width font used for data readouts and code previews.
*   **Spacings**: Adjusting the `line-height` (usually $1.4$ to $1.6$) and `letter-spacing` is key to preventing text from looking crowded.

### 4. Component Depth: Glassmorphism & Drop Shadows (Look at `styles.css` → `.custom-card`)
Modern web UI feels premium when it has layers and depth:
*   **Backdrop Blur**: `backdrop-filter: blur(12px)` mimics frosted glass, letting the background color peek through.
*   **Dynamic Shadows**: We use `box-shadow` values that grow softer and wider as shadow opacity increases, creating the illusion of elevation (lifting the card closer to the screen).

---

## 🖥️ How the Backend Works (`backend/server.ps1`)

Most full-stack applications require Node.js, Python, or Ruby. To keep this project completely zero-install, we built the backend using Windows **PowerShell**.

It starts a `.NET System.Net.HttpListener` on port 5000:
1.  **Static File Server**: When your browser requests `/`, `/styles.css`, or `/app.js`, the PowerShell script reads the file from disk and writes the raw bytes into the network stream, returning the correct MIME type (e.g., `text/html`, `text/css`, `application/javascript`).
2.  **REST API endpoints**:
    *   `GET /api/boards` reads `backend/db.json` and sends saved themes to the UI.
    *   `POST /api/boards` accepts JSON data, generates a new GUID, appends it to `db.json`, and saves.
    *   `DELETE /api/boards?id={id}` removes a theme by its unique identifier.
3.  **Local Fallback**: If you open `index.html` without running the server, `app.js` catches the connection failure and switches to **LocalStorage Mode**, saving your designs directly in the web browser instead!

---

## 🐙 How to Put Your Code on GitHub

To share your project on GitHub, you have two options:

### Option A: Direct Web Upload (No Software Needed)
1. Go to [github.com](https://github.com/) and log in (or create a free account).
2. Click the green **"New"** button to create a new repository.
3. Name your repository (e.g., `designcraft-playbook`) and click **"Create repository"**.
4. You will see a setup page. Look for the sentence: *"Get started by creating a new file or uploading an existing file."* Click **"uploading an existing file"**.
5. Drag and drop all the folders (`frontend`, `backend`) and files (`run.bat`, `README.md`) from your local directory into the box.
6. Click **"Commit changes"** at the bottom of the page. Your files are now live on GitHub!

### Option B: Using Git Command Line (Recommended for Developers)
If you want to learn Git command-line, follow these steps:

1. **Install Git**: Download and run the installer from [git-scm.com](https://git-scm.com/).
2. **Open Git Bash or Command Prompt** inside your project folder (`agy-cli-projects`).
3. **Initialize the local Git repository**:
   ```bash
   git init
   ```
4. **Stage all files** to be committed:
   ```bash
   git add .
   ```
5. **Create your first commit**:
   ```bash
   git commit -m "Initial commit: DesignCraft Web Design Playground"
   ```
6. **Link it to GitHub**:
   - Create a repository on GitHub (same as Option A step 1-3).
   - Copy the repository URL (e.g., `https://github.com/YOUR_USERNAME/designcraft-playbook.git`).
   - Run:
     ```bash
     git remote add origin https://github.com/YOUR_USERNAME/designcraft-playbook.git
     ```
7. **Push to GitHub**:
   - Rename your branch to main and upload:
     ```bash
     git branch -M main
     git push -u origin main
     ```

Now you have a fully functional fullstack web application running locally and archived on your GitHub page!
